package com.springbook.biz.anonymous;




import org.springframework.data.jpa.repository.JpaRepository;



public interface AnonymousRepository extends JpaRepository<Anonymous, Integer> {
   
}
