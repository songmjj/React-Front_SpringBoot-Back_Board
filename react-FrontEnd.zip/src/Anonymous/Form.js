import React from 'react'
import axios from "axios"
import { history } from '../component/history'
import '../App.css'
import { CKEditor } from '@ckeditor/ckeditor5-react'
import ClassicEditor from '@ckeditor/ckeditor5-build-classic'

export default class Form extends React.Component{
  constructor(props) {
		super(props)

		// 파라미터에서 id를 읽어와 수정모드인지 추가모드인지 확인
		this.state = {
      no: props.match.params.no,
      mode: props.match.params.no ? 'edit' : 'add',
      anonymousTitle: '',
      anonymousContents: '',
    }

  }
  
  componentDidMount() {
    const { no } = this.state // id를 읽어옴
		if(!no) return // id가 없는경우 종료

		// 수정모드이므로 게시글 정보를 읽어와 저장
		axios.get('/read/' + no)
      .then(res => this.setState({ ...res.data }))
	}
  
  action() {
    if (!document.getElementById("anonymousTitle").value) {
			alert("제목 입력해주세요");
			return false;
    }
    if (!document.getElementById("anonymousId").value) {
			alert("아이디 입력해주세요");
			return false;
    }
    if (!document.getElementById("Pw").value) {
			alert("비번 입력해주세요");
			return false;
    }
    const { no,anonymousTitle, anonymousContents, mode,anonymousHits,anonymousDate,anonymousId,anonymousPw,Pw } = this.state

    let form = new FormData()
    form.append('anonymousTitle',anonymousTitle)
    form.append('anonymousContents',anonymousContents)
    form.append('anonymousId',anonymousId)
    form.append('anonymousPw',Pw)
    if(mode == 'add') {
    axios.post(`addAnonymous`,form).then(function (response) {
      console.log(response)
      history.goBack()
    }).catch(function (error){
      console.log(error)
    })
  } else {
    if(document.getElementById("anonymousPw").value == document.getElementById("Pw").value){
    form.append('anonymousNo',no) // 글번호
    form.append('anonymousDate',anonymousDate) // 글작성날짜
    form.append('anonymousHits',anonymousHits) // 조회수
    axios.put(`/editAnonymous`,form).then(function (response) {
      console.log(response)
      history.goBack()
    }).catch(function (error){
      console.log(error)
    })
  }else{
    alert("비번이 맞지않습니다.")
  }
  }
    

}


  cancel() {
    this.props.history.push('/');
  }
  render() {
    const { no,anonymousTitle, anonymousContents, mode,anonymousHits,anonymousDate,anonymousId,anonymousPw,Pw } = this.state
  return (<>
      <div className='form-wrapper'>
      <h1> {mode == 'add' ? '글쓰기' : '글수정'} </h1>
            <input type="hidden" value={no} />
            <input type="hidden" value={anonymousDate} />
            <input type="hidden" value={anonymousHits} />
            <input type="hidden" id="anonymousPw" name="anonymousPw" value={anonymousPw} />

      제목 :<input className="title-input"
	type='text'
    placeholder='제목'
    value={anonymousTitle}
    onChange={(event) => this.setState({ anonymousTitle: event.target.value })}
    name='anonymousTitle'
    id='anonymousTitle'
/>
아이디 :<input className="id-input"
type='text'
  placeholder='아이디'
  
  value={anonymousId}
  onChange={(event) => this.setState({ anonymousId: event.target.value })}
  name='anonymousId'
  id='anonymousId'
/>
비번 :<input className="pw-input"

	type='password'
    placeholder='비번'
    onChange={(event) => this.setState({ Pw: event.target.value })}
    name='Pw'
    id='Pw'
/>
        <CKEditor
          editor={ClassicEditor}
          data={anonymousContents}
          onReady={editor => {
            // You can store the "editor" and use when it is needed.
            console.log('Editor is ready to use!', editor);
          }}
          onChange={(event, editor) => {
            const data = editor.getData()
            console.log({ event, editor, data })
            this.setState({ anonymousContents: data })
          }}
          onBlur={(event, editor) => {
            console.log('Blur.', editor);
          }}
          onFocus={(event, editor) => {
            console.log('Focus.', editor);
          }}
        />
      <button className="btn btn-success" onClick={() => this.action()}>{mode == 'add' ? '작성하기' : '수정하기'}</button>
      
      <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft:"10px"}}>취소</button>
      </div>
                
                </>)
  
}
}
