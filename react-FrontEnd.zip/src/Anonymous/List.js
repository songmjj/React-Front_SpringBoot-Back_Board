import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'


export default class List extends React.Component{
    constructor(props) {
        super(props);
    // # 1. 
        this.state = { 
            data: [],

            number: 0,
            totalPages: 0,
            currentPage: 0,
            totalElements: 0,
            searchKeyword: "",
        }
		
    }
    componentDidMount() {
        axios.get(`pagelist`).then((res) => {
            this.setState({ 
                data: res.data.content,
                totalPages: res.data.totalPages,
                totalElements : res.data.totalElements,
                currentPage: res.data.number
            })
            console.log(res)
        });
        // axios.get(`getAnonymouslist`).then((res) => {
        //     this.setState({ data: res.data})
        //     console.log(res)
        // });
    }

    readBoard(no) {
        this.props.history.push(`/read/${no}`);
    }
    changePage(currentPage){
        const { searchKeyword } = this.state // 검색어를 읽어옴

        axios.get(`pagelist`,{ params: { page: currentPage,searchKeyword } }).then((res) => {
            this.setState({ 
                data: res.data.content,
                totalPages: res.data.totalPages,
                totalElements : res.data.totalElements,
                currentPage: res.data.number
            })
            console.log(res)
        });
    }
   nextPage(){
       if(this.state.currentPage<Math.ceil(this.state.totalElements/5)-1)
    this.changePage(this.state.currentPage+1)
   }
   prevPage(){
       if(this.state.currentPage>0){
    this.changePage(this.state.currentPage-1)
       }
    }


    render() {
        return (
            <>
            <div>
                <div class="container">
	<h2>익명게시판</h2>
	<table class="table table-hover">
    <colgroup>
				<col width="10%"/>
				<col width="50%"/>
				<col width="20%"/>
                <col width="15%"/>
                <col width="5%"/>
			</colgroup>
	  <thead>
	    <tr>
        <th scope="col">No</th>
        <th scope="col">제목</th>
        <th scope="col">작성자</th>
        <th scope="col">등록일</th>
        <th scope="col">조회수</th>
	    </tr>
	  </thead>
	  <tbody>
      {
                                this.state.data.map(
                                    data => 
                                    <tr key = {data.anonymousNo}>
                                        <td>{data.anonymousNo} </td>
                                        <td><Link onClick = {() => this.readBoard(data.anonymousNo)}>{data.anonymousTitle}</Link> </td>
                                        <td>{data.anonymousId} </td>
                                        <td>{data.anonymousDate}</td>
                                        <td>{data.anonymousHits}</td>
                                    </tr>
                                )
                            }
	  </tbody>
          <Link to={`/add`}><button className="btn btn-primary" >글쓰기</button></Link>
                                <td align="right"><button className="btn btn-info btn-xs" onClick={()=>this.prevPage()}>이전</button>
                                <button button className="btn btn-info btn-xs" onClick={()=>this.nextPage()}>다음</button></td>

	</table>
</div>
                </div>
                </>
        );
    }
}
