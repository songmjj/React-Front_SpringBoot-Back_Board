import React from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
import '../App.css'
import ReactHtmlParser from 'react-html-parser'

export default class View extends React.Component{
    constructor(props) {
        super(props)
    // # 1. 
        this.state = { 
            no: this.props.match.params.no,
            data: []
        }
		
    }
    // # 2. 
    componentDidMount() {
        axios.get(this.state.no).then((res) => {
            this.setState({ data: res.data});
        });
    }
    deleteOne(no) {
        if(document.getElementById("anonymousPw").value == document.getElementById("Pw").value){
		axios.delete('/delete/'+no, { data: { no } })
			.then(res => {
				console.log(res.data.msg) // 결과 알림
				this.props.history.push('/');
            })
        }else{
            alert("비번이 맞지않습니다.")
        }
    }
    editOne(no){
        axios.get('/edit/'+no)
        .then(res => {
            console.log(res.data) // 결과 알림
        })
        
    }




    // # 3.
    render() {
        const {anonymousPw,Pw } = this.state
        return (
            <>
            <input type="hidden" id="anonymousPw" name="anonymousPw" value={this.state.data.anonymousPw} />
            <div>
                <div className="App">
                <h1>글번호 : {this.state.data.anonymousNo} &nbsp;&nbsp;
                    제목 : {this.state.data.anonymousTitle} &nbsp;&nbsp;&nbsp; 작성자 : {this.state.data.anonymousId} &nbsp;&nbsp;&nbsp;
      <input className="pw-input"
    type='password'
    placeholder='비번'
    onChange={(event) => this.setState({ Pw: event.target.value })}
    name='Pw'
    id='Pw'
    />
      <button className="btn btn-warning" onClick = {() => this.deleteOne(this.state.data.anonymousNo)}>글삭제</button> </h1>
      
      <div className='container'>
        <div>
        {ReactHtmlParser(this.state.data.anonymousContents)}
        </div>
      </div>
      
      <Link to={`/edit/${this.state.data.anonymousNo}`}><button className="btn btn-success" >글수정</button></Link>
      <Link to={`/`}><button className="btn btn-info" >글목록</button></Link>
      
      </div>
                </div>
                </>
        );
    }
}
