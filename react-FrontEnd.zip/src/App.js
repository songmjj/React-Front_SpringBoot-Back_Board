import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import Form from './Anonymous/Form';
import List from './Anonymous/List';
import View from './Anonymous/View';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div>
    <Router>
        <Switch> 
        <Route exact path="/" component={List}></Route>
        <Route path = "/read/:no" component = {View}></Route>
        <Route exact path="/add" component={Form}></Route>
        <Route path="/edit/:no" component={Form}></Route>
        </Switch>
    
    
    </Router>
    </div>

  );
}

export default App;
