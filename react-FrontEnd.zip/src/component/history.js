// 브라우저 히스토리 모듈 생성 및 리턴
import { createBrowserHistory } from 'history'
export let history = createBrowserHistory()